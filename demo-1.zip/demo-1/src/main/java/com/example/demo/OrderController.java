package com.example.demo;

@RestController
public class OrderController {

}
