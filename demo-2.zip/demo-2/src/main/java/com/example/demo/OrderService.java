package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

	@Autowired
	OrderRepository repository;

	public void saveOrder(OrderVO order) {
		System.out.println(order);
		repository.save(order);
	}
	public List<OrderVO> getOrders() {
		return repository.findAll();
	}
}
