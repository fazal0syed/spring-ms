package com.example.demo.user;

public class UserOrders {

	String item;

	float price;

}
