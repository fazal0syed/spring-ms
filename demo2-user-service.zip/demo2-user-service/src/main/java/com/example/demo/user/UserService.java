package com.example.demo.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UserService {


	@Autowired
	RestTemplate template;

	@Autowired
	UserRepository repository;
	
	public void create(UserVO user) {
		repository.save(user);
	}
	
	public UserData getOrders(String userId) {
		UserData userData = new UserData(); 
		UserDetails userDetails = getUserDetails(userId);
		userData.setUserDetails(userDetails);
		ResponseEntity<String> emailAddress = template.getForEntity("http://localhost:8761/EMAIL-SERVICE?userId="+userId, String.class);
		userData.setUserEmail(emailAddress.getBody());

		return userData;
	}

	public UserDetails getUserDetails(String userId) {
		UserVO user = repository.findByUserId(userId);
		UserDetails userDetails = new UserDetails();
		userDetails.setName(user.getName());
		userDetails.setUserId(user.getUserId());
		return userDetails;
	}

}
