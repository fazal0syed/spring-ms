package com.example.demo.user;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface UserRepository extends JpaRepository<UserVO, String> {

	@Query("select u from UserVO u where u.userId = ?1")
	UserVO findByUserId(String userId);	
}
