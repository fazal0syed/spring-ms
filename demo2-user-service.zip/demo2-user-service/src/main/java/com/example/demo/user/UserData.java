package com.example.demo.user;

public class UserData {
	
	UserDetails userDetails;
	UserOrders userOrders;
	String userEmail;
	
	public UserDetails getUserDetails() {
		return userDetails;
	}
	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}
	public UserOrders getUserOrders() {
		return userOrders;
	}
	public void setUserOrders(UserOrders userOrders) {
		this.userOrders = userOrders;
	}
	
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	@Override
	public String toString() {
		return "UserData [userDetails=" + userDetails + ", userOrders=" + userOrders + "]";
	}

}
