package com.example.demo.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

	@Autowired
	UserService service;

	@PostMapping("/user")
	public void createUser(@RequestBody UserVO user) {
		service.create(user);
	}

	@GetMapping("/user/{userId}")
	public UserData createUser(@PathVariable String userId) {
		return service.getOrders(userId);
	}
}
