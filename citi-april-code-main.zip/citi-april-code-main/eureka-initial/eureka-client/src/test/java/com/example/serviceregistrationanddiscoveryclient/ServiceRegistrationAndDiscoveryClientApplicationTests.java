package com.example.serviceregistrationanddiscoveryclient;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ServiceRegistrationAndDiscoveryClientApplicationTests {

	@Test
	public void contextLoads() {
	}

}
